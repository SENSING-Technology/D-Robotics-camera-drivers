#!/usr/bin/env python3
"""Generate the mixed S36 + S56 RX0 overlay used on the S600.

The script deliberately starts from the reviewed overlay topology and only
changes named properties inside known nodes.  This preserves labels,
phandles and endpoint relationships while making timing and stream settings
reproducible.
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
SOURCE_TEMPLATE = SCRIPT_DIR / "s600_sensing_s56_rx0_portABC_yuv.dtso"
LOCAL_TEMPLATE = SCRIPT_DIR / "s600_sensing_s56_rx0_portABC_yuv.build.dtso"
DEFAULT_TEMPLATE = SOURCE_TEMPLATE if SOURCE_TEMPLATE.is_file() else LOCAL_TEMPLATE


@dataclass(frozen=True)
class Node:
    marker: str


DSER = Node("rx0_dser: rx0_max96712@29")
MONO0 = Node("rx0_sensing@11")
MONO1 = Node("rx0_sensing@12")
S56_LEADER = Node("rx0_s56@22")
S56_PARTNER = Node("rx0_s56@23")
MIPI_PORTS = tuple(Node(f"port@{index}") for index in range(4))


def parse_int(value: str) -> int:
    return int(value, 0)


def find_node_span(text: str, node: Node, start_at: int = 0) -> tuple[int, int]:
    marker_at = text.find(node.marker, start_at)
    if marker_at < 0:
        raise ValueError(f"node marker not found: {node.marker!r}")

    open_at = text.find("{", marker_at)
    if open_at < 0:
        raise ValueError(f"opening brace not found for: {node.marker!r}")

    depth = 0
    for index in range(open_at, len(text)):
        char = text[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return marker_at, index + 1

    raise ValueError(f"closing brace not found for: {node.marker!r}")


def replace_property(text: str, node: Node, prop: str, value: str,
                     start_at: int = 0) -> str:
    begin, end = find_node_span(text, node, start_at)
    block = text[begin:end]
    pattern = re.compile(
        rf"(?m)^(?P<indent>[ \t]*){re.escape(prop)}[ \t]*=[ \t]*"
        rf"(?P<old>[^;]+);(?P<comment>[^\r\n]*)$"
    )
    matches = list(pattern.finditer(block))
    if len(matches) != 1:
        raise ValueError(
            f"expected exactly one {prop!r} in {node.marker!r}, "
            f"found {len(matches)}"
        )
    block = pattern.sub(
        lambda match: (
            f"{match.group('indent')}{prop} = {value};"
            f"{match.group('comment')}"
        ),
        block,
        count=1,
    )
    return text[:begin] + block + text[end:]


def replace_all_lane_rates(text: str, lane_rate: int) -> str:
    fragment = 'target-path = "/soc/mipi_host@0x37420000/"'
    fragment_at = text.find(fragment)
    if fragment_at < 0:
        raise ValueError("RX0 MIPI fragment not found")

    cursor = fragment_at
    for node in MIPI_PORTS:
        text = replace_property(text, node, "lane-rate", f"<{lane_rate}>", cursor)
        _, cursor = find_node_span(text, node, cursor)
    return text


def generate(args: argparse.Namespace) -> str:
    text = args.template.read_text(encoding="utf-8")

    text = replace_property(text, DSER, "soc_trig_pin", f"<{args.soc_trig_pin}>")
    text = replace_property(
        text, DSER, "pwms",
        f"<&lpwm0 0 {args.trigger_period_ns} {args.trigger_duty_ns}>",
    )
    text = replace_property(text, DSER, "trig_src", f"<{args.lpwm_trig_src}>")
    text = replace_property(text, DSER, "trig_mode", f"<{args.lpwm_trig_mode}>")

    for node in (MONO0, MONO1):
        text = replace_property(text, node, "width", f"<{args.mono_width}>")
        text = replace_property(text, node, "height", f"<{args.mono_height}>")
        text = replace_property(text, node, "gmsl-link-rate", f"<{args.gmsl_link_rate}>")
        text = replace_property(text, node, "mfp-trigger", f"<{args.trigger_gpio_id}>")

    for node in (S56_LEADER, S56_PARTNER):
        text = replace_property(text, node, "width", f"<{args.stereo_width}>")
        text = replace_property(text, node, "height", f"<{args.stereo_height}>")
        text = replace_property(text, node, "gmsl-link-rate", f"<{args.gmsl_link_rate}>")

    text = replace_property(
        text, S56_LEADER, "sensing,trigger-mode",
        f"<{args.sensor_trigger_mode}>",
    )
    text = replace_property(
        text, S56_LEADER, "sensing,trigger-mfp",
        f"<{args.sensor_trigger_mfp}>",
    )
    text = replace_property(
        text, S56_LEADER, "sensing,trigger-gpio-id",
        f"<{args.trigger_gpio_id}>",
    )
    text = replace_property(
        text, S56_LEADER, "sensing,trigger-period-ns",
        f"<{args.trigger_period_ns}>",
    )
    text = replace_property(
        text, S56_LEADER, "sensing,trigger-duty-ns",
        f"<{args.trigger_duty_ns}>",
    )
    text = replace_all_lane_rates(text, args.mipi_lane_rate)

    fps = 1_000_000_000 / args.trigger_period_ns
    text = re.sub(
        r"(?m)(pwms\s*=\s*<[^;]+>;)[^\r\n]*$",
        rf"\1 /* {fps:.6g}Hz, {args.trigger_duty_ns / 1000:.6g}us pulse */",
        text,
        count=1,
    )
    return text


def validate(args: argparse.Namespace) -> None:
    if args.trigger_period_ns <= 0:
        raise ValueError("trigger period must be positive")
    if not 0 < args.trigger_duty_ns < args.trigger_period_ns:
        raise ValueError("trigger duty must be positive and shorter than period")
    if args.lpwm_trig_mode not in (0, 1):
        raise ValueError("LPWM trig_mode must be 0 or 1")
    if args.sensor_trigger_mode not in (0, 1):
        raise ValueError("sensor trigger mode must be 0 or 1")
    if args.sensor_trigger_mode == 1 and args.trigger_gpio_id < 4:
        raise ValueError("S600 MAX96712 GPIO tunnel ID must be at least 4")
    if args.sensor_trigger_mfp != 7:
        raise ValueError("the current S56 module routes FSIN through MAX9295D MFP7")


def bandwidth_report(args: argparse.Namespace) -> str:
    fps = 1_000_000_000 / args.trigger_period_ns
    mono_bps = args.mono_width * args.mono_height * 16 * fps * 2
    stereo_bps = args.stereo_width * args.stereo_height * 10 * fps * 2
    total_bps = mono_bps + stereo_bps
    lane_capacity = args.mipi_lane_rate * 1_000_000 * 4
    return (
        f"fps={fps:.6f}, CSI payload={total_bps / 1e9:.6f} Gbit/s "
        f"(mono={mono_bps / 1e9:.6f}, S56={stereo_bps / 1e9:.6f}), "
        f"configured 4-lane rate={lane_capacity / 1e9:.3f} Gbit/s, "
        f"payload utilization={100 * total_bps / lane_capacity:.2f}%"
    )


def compile_dtbo(args: argparse.Namespace) -> None:
    cpp = shutil.which(args.cpp)
    dtc = shutil.which(args.dtc)
    if not cpp:
        raise RuntimeError(f"preprocessor not found: {args.cpp}")
    if not dtc:
        raise RuntimeError(f"device-tree compiler not found: {args.dtc}")

    include_args: list[str] = []
    for include_dir in args.include_dir:
        include_args.extend(("-I", str(include_dir.resolve())))

    with tempfile.TemporaryDirectory(prefix="s600-dt-") as temp_dir:
        preprocessed = Path(temp_dir) / "overlay.dts"
        cpp_cmd = [
            cpp, "-nostdinc", "-undef", "-D__DTS__",
            "-x", "assembler-with-cpp", *include_args,
            str(args.output.resolve()),
        ]
        with preprocessed.open("wb") as output_file:
            subprocess.run(cpp_cmd, check=True, stdout=output_file)

        subprocess.run(
            [dtc, "-@", "-I", "dts", "-O", "dtb",
             "-o", str(args.dtbo.resolve()), str(preprocessed)],
            check=True,
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--template", type=Path, default=DEFAULT_TEMPLATE)
    parser.add_argument("--output", type=Path,
                        default=SCRIPT_DIR / "s600_sensing_s56_rx0_portABC_yuv.generated.dtso")
    parser.add_argument("--dtbo", type=Path,
                        help="also compile this DTBO using cpp and dtc")
    parser.add_argument("--include-dir", type=Path, action="append", default=[],
                        help="cpp include directory; repeat as needed")
    parser.add_argument("--cpp", default="cpp")
    parser.add_argument("--dtc", default="dtc")

    parser.add_argument("--lpwm-trig-mode", type=parse_int, choices=(0, 1), default=0,
                        help="0=software-start/free-run, 1=AON RTC/PPS sync")
    parser.add_argument("--lpwm-trig-src", type=parse_int, default=0)
    parser.add_argument("--trigger-period-ns", type=parse_int, default=40_000_000)
    parser.add_argument("--trigger-duty-ns", type=parse_int, default=10_000)
    parser.add_argument("--soc-trig-pin", type=parse_int, default=5)
    parser.add_argument("--sensor-trigger-mode", type=parse_int, choices=(0, 1), default=1)
    parser.add_argument("--sensor-trigger-mfp", type=parse_int, default=7)
    parser.add_argument("--trigger-gpio-id", type=parse_int, default=7)

    parser.add_argument("--mono-width", type=parse_int, default=3840)
    parser.add_argument("--mono-height", type=parse_int, default=2160)
    parser.add_argument("--stereo-width", type=parse_int, default=2560)
    parser.add_argument("--stereo-height", type=parse_int, default=1984)
    parser.add_argument("--gmsl-link-rate", type=parse_int, default=6)
    parser.add_argument("--mipi-lane-rate", type=parse_int, default=4800,
                        help="per-lane rate in Mbit/s")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        validate(args)
        if not args.template.is_file():
            raise FileNotFoundError(f"template not found: {args.template}")
        generated = generate(args)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("w", encoding="utf-8", newline="\n") as output_file:
            output_file.write(generated)
        print(f"generated: {args.output}")
        print(bandwidth_report(args))
        if args.dtbo:
            args.dtbo.parent.mkdir(parents=True, exist_ok=True)
            compile_dtbo(args)
            print(f"compiled:  {args.dtbo}")
        return 0
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        parser.exit(1, f"error: {error}\n")


if __name__ == "__main__":
    sys.exit(main())
