build/objects/src/main/cpp/HTTPServer/HTTPServer.o: \
 src/main/cpp/HTTPServer/HTTPServer.cpp src/main/include/ATL/ATLConfig.h \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h src/main/include/ATL/ATLLogger.h \
 src/main/include/ARMCPP11/Mutex.h src/main/include/ATL/ATLNetwork.h \
 src/main/include/CommandManager/CommandManager.h \
 src/main/include/ATL/ATLTypes.h src/main/include/ATL/ATLObject.h \
 src/main/include/ARMCPP11/Atomic.h src/main/include/ATL/ATLComponent.h \
 src/main/include/ATL/ATLObject.h src/main/include/ATL/ATLTemplates.h \
 src/main/include/ATL/ATLConfig.h src/main/include/ATL/ATLTemplates.h \
 src/main/include/AccessManager/AccessManager.h \
 src/main/include/ATL/ATLError.h src/main/include/BusManager/BusManager.h \
 src/main/include/BusManager/TransferPacket.h \
 src/main/include/BusManager/BaseDriverInterface.h \
 src/main/include/BusManager/TransferPacket.h \
 src/main/include/ARMCPP11/ConditionVariable.h \
 src/main/include/ARMCPP11/Chrono.h src/main/include/ARMCPP11/Ratio.h \
 src/main/include/AccessManager/AccessRequest.h \
 src/main/include/AccessManager/RegisterDirectAccess.h \
 src/main/include/AccessManager/AccessBase.h \
 src/main/include/BusManager/BaseDriverInterface.h \
 src/main/include/AccessManager/FWDebugAccess.h \
 src/main/include/ATL/ATLThread.h src/main/include/ARMCPP11/Thread.h \
 src/main/include/AccessManager/FWStreamAccess.h \
 src/main/include/AccessManager/BufferManager.h \
 src/main/include/ARMCPP11/SharedPtr.h \
 src/main/include/CommandManager/RequestParser.h \
 src/main/include/CommandManager/AccessManagerConfig.h \
 src/main/include/CommandManager/ClientCommand.h \
 src/main/include/CommandManager/ResponseWriter.h \
 src/main/include/HTTPServer/EventEngine.h \
 src/main/include/HTTPServer/HTTPServer.h
