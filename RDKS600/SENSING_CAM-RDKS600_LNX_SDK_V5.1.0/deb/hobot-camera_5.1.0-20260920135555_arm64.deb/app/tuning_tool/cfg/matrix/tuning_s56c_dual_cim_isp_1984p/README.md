# S56C dual hbplayer preview, S600 RX3

Added to SDK `source/hobot-camera/tuning_tool/` and deployed to board `/app/tuning_tool/` on 2026-09-03.

Start on sunrise@192.168.160.132:

```bash
cd /app/tuning_tool/scripts
sudo bash run_tuning.sh 13 1
```

Current menu: 13 = S56C_RGGB; sub-item 1 = Raw10_S56C_DUAL_RDK-S600. If other menu items are added, use the item name rather than assuming index 13 remains fixed.

For a bounded test: `sudo bash run_tuning.sh 13 1 r30`.

Wait approximately 15 seconds for sensor initialization. On Windows hbplayer set board address 192.168.160.132, port 10086, Apply, Connect. Start with YUV preview. RAW sent by this tuning configuration is compact RAW10; it is not the separately verified 16-bit MSB unpacked capture. Do not use the unpacked RAW display settings on this stream.

SDK files:

- `tuning_tool/scripts/tuning_menu.sh`: appended S56 menu only.
- `tuning_tool/cfg/matrix/tuning_s56c_dual_cim_isp_1984p/hb_superdev.json`
- `tuning_tool/cfg/matrix/tuning_s56c_dual_cim_isp_1984p/mipi.json`
- `tuning_tool/cfg/matrix/tuning_s56c_dual_cim_isp_1984p/vpm_config.json`
- `tuning_tool/cfg/matrix/tuning_s56c_dual_cim_isp_1984p/lpwm_30fps.json`

Topology: logical link0/VC0/ISP0 and logical link1/VC1/ISP1, shared physical GMSL A, RX3 C-PHY, 2560x1984 RAW10, 30fps. Both ISP contexts use slot4. Master LPWM is configured only on pipeline0. Native SDK tuning_bin is retained.

Validation: shell syntax and selected menu command checked; hb_cam_init succeeded; hbplayer listener active on 0.0.0.0:10086. During the menu-driven test, CIM VC0/VC1 DMA counts reached 498/500, with width, height, IPI drop and DMA drop counters all zero. Windows hbplayer client rendering has not been directly verified in this session.

Noncompact RAW10 initially failed ISP bind with `isp wstride=3200, cim wstride5120`; restored the already tested compact ISP input instead of bypassing kernel checks. Noncompact RAW capture remains available through the separate get_multi_vin_loose program.

Old experimental `tuning_s56c_cim_isp_1984p` directory was preserved and is not used by the new menu. Original menu backups: build host `tmp/s56_hbn_fix_20260903/tuning_menu.sh.before`, board `/home/sunrise/s56_hbn_port_20260902/tuning-test/tuning_menu.sh.before`.

Use one camera application at a time; stop with Ctrl+C. Configuration changes are uncommitted. No new kernel or sensor binary changes were made for this tuning integration. SDK packaging should include the new source tuning_tool assets; a full SDK/deb rebuild was not performed in this task.
