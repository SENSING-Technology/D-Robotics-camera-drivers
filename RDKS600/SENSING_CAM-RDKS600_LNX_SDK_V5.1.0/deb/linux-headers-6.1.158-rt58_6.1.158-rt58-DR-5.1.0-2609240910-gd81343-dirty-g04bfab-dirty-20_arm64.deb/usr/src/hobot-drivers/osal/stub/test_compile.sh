#!/bin/bash
# SPDX-License-Identifier: GPL-2.0
#
#

OSAL_TEST=../../../test/qualitytest/source/S21_Runtime/S21E13_OSAL/api_test/

aarch64-linux-gnu-gcc -O2 -C \
					${OSAL_TEST}/osal_test_debug.c   \
					${OSAL_TEST}/osal_test_alloc.c \
					${OSAL_TEST}/osal_test_atomic.c \
					${OSAL_TEST}/osal_test_bitops.c \
					${OSAL_TEST}/osal_test_io.c \
					${OSAL_TEST}/osal_test_list.c \
					${OSAL_TEST}/osal_test_thread.c \
					${OSAL_TEST}/osal_test_fifo.c \
					${OSAL_TEST}/osal_test_lock.c \
					${OSAL_TEST}/osal_test_sem.c \
					${OSAL_TEST}/osal_test_complete.c \
					${OSAL_TEST}/osal_test_time.c	   \
					${OSAL_TEST}/osal_test_waitqueue.c	   \
					-I./ -D__OSAL_STUB__ -DSIGINT=8

