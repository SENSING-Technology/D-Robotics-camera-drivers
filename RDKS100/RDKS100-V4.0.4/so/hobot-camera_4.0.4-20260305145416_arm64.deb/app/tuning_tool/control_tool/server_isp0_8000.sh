#!/bin/sh
eth_id=eth1
ip_id=`ifconfig ${eth_id} | grep inet\ | awk  '{print $2}'`
echo ${eth_id} ${ip_id}

./act-server --http-address=${ip_id} --http-port=8000 --fw-acc=stream --fw-channel=chardev --fw-dev=/dev/ac_isp --hw-acc=stream --hw-buf-size=1024 --hw-channel=devmem --hw-dev=/dev/mem --hw-mem-offset=0x37440000 --hw-mem-size=0x400000 --log=3 &
