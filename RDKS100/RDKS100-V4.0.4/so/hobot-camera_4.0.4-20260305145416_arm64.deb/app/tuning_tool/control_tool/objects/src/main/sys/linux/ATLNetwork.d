build/objects/src/main/sys/linux/ATLNetwork.o: \
 src/main/sys/linux/ATLNetwork.cpp src/main/include/ATL/ATLNetwork.h
