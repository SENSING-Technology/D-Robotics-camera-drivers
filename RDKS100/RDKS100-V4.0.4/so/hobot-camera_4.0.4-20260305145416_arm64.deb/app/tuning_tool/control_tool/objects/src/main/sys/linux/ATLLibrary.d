build/objects/src/main/sys/linux/ATLLibrary.o: \
 src/main/sys/linux/ATLLibrary.cpp src/main/include/ATL/ATLLibrary.h \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h
