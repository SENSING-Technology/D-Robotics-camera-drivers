build/objects/src/main/cpp/ARMCPP11/Thread.o: \
 src/main/cpp/ARMCPP11/Thread.cpp src/main/include/ARMCPP11/Thread.h \
 src/main/include/ARMCPP11/Chrono.h src/main/include/ARMCPP11/Ratio.h
