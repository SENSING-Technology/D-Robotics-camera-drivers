build/objects/src/main/cpp/ATL/ATLError.o: src/main/cpp/ATL/ATLError.cpp \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h
