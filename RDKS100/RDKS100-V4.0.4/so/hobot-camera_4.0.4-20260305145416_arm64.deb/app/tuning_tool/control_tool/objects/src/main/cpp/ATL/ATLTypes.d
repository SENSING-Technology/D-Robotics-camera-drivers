build/objects/src/main/cpp/ATL/ATLTypes.o: src/main/cpp/ATL/ATLTypes.cpp \
 src/main/include/ATL/ATLTypes.h src/main/include/ATL/ATLPlatform.h
