build/objects/src/main/cpp/ATL/ATLLogger.o: \
 src/main/cpp/ATL/ATLLogger.cpp src/main/include/ATL/ATLLogger.h \
 src/main/include/ATL/ATLTypes.h src/main/include/ATL/ATLPlatform.h \
 src/main/include/ARMCPP11/Mutex.h src/main/include/ATL/ATLError.h \
 src/main/include/ARMCPP11/Chrono.h src/main/include/ARMCPP11/Ratio.h
