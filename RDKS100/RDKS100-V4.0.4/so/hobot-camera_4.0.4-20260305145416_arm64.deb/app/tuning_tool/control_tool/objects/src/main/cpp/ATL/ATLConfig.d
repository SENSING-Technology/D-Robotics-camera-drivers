build/objects/src/main/cpp/ATL/ATLConfig.o: \
 src/main/cpp/ATL/ATLConfig.cpp src/main/include/ATL/ATLConfig.h \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h src/main/include/ATL/ATLLogger.h \
 src/main/include/ARMCPP11/Mutex.h
