build/objects/src/main/cpp/BusManager/TransferPacket.o: \
 src/main/cpp/BusManager/TransferPacket.cpp \
 src/main/include/BusManager/TransferPacket.h \
 src/main/include/ATL/ATLTypes.h src/main/include/ATL/ATLPlatform.h \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLObject.h src/main/include/ARMCPP11/Atomic.h \
 src/main/include/ATL/ATLLogger.h src/main/include/ARMCPP11/Mutex.h \
 src/main/include/ATL/ATLTemplates.h src/main/include/ATL/ATLError.h
