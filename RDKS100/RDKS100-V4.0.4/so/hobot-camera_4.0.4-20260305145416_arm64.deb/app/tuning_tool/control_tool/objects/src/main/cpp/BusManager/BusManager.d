build/objects/src/main/cpp/BusManager/BusManager.o: \
 src/main/cpp/BusManager/BusManager.cpp src/main/include/ATL/ATLConfig.h \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h \
 src/main/include/BusManager/BusManager.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLObject.h \
 src/main/include/ARMCPP11/Atomic.h src/main/include/ATL/ATLTemplates.h \
 src/main/include/BusManager/TransferPacket.h \
 src/main/include/ATL/ATLLogger.h src/main/include/ARMCPP11/Mutex.h \
 src/main/include/BusManager/BaseDriverInterface.h \
 src/main/include/ATL/ATLComponent.h src/main/include/ATL/ATLObject.h \
 src/main/include/ATL/ATLTemplates.h src/main/include/ATL/ATLConfig.h \
 src/main/include/BusManager/TransferPacket.h \
 src/main/include/ARMCPP11/ConditionVariable.h \
 src/main/include/ARMCPP11/Chrono.h src/main/include/ARMCPP11/Ratio.h \
 src/main/include/BusManager/DriverFactory.h
