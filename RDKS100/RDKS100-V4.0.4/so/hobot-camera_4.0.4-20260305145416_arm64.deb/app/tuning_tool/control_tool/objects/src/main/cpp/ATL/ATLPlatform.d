build/objects/src/main/cpp/ATL/ATLPlatform.o: \
 src/main/cpp/ATL/ATLPlatform.cpp src/main/include/ATL/ATLPlatform.h
