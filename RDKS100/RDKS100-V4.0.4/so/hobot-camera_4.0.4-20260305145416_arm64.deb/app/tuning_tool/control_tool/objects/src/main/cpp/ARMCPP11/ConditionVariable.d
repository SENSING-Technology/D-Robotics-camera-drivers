build/objects/src/main/cpp/ARMCPP11/ConditionVariable.o: \
 src/main/cpp/ARMCPP11/ConditionVariable.cpp \
 src/main/include/ARMCPP11/ConditionVariable.h \
 src/main/include/ARMCPP11/Mutex.h src/main/include/ARMCPP11/Chrono.h \
 src/main/include/ARMCPP11/Ratio.h
