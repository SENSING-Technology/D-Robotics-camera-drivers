build/objects/src/main/cpp/CommandManager/ResponseWriter.o: \
 src/main/cpp/CommandManager/ResponseWriter.cpp \
 src/main/include/ATL/ATLLogger.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h src/main/include/ARMCPP11/Mutex.h \
 src/main/include/CommandManager/ResponseWriter.h \
 src/main/include/ATL/ATLTypes.h src/main/include/ATL/ATLObject.h \
 src/main/include/ARMCPP11/Atomic.h src/main/include/ATL/ATLTemplates.h \
 src/main/include/ATL/ATLError.h
