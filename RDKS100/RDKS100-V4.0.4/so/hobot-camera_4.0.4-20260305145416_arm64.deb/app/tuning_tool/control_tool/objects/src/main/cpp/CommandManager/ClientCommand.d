build/objects/src/main/cpp/CommandManager/ClientCommand.o: \
 src/main/cpp/CommandManager/ClientCommand.cpp \
 src/main/include/CommandManager/ClientCommand.h \
 src/main/include/ATL/ATLObject.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h src/main/include/ARMCPP11/Atomic.h \
 src/main/include/ATL/ATLTypes.h
