build/objects/src/main/cpp/BusManager/Driver/FTDIDriver.o: \
 src/main/cpp/BusManager/Driver/FTDIDriver.cpp \
 src/main/include/ATL/ATLLogger.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h src/main/include/ARMCPP11/Mutex.h \
 src/main/include/ATL/ATLLibrary.h src/main/include/ATL/ATLError.h \
 src/main/cpp/BusManager/Driver/FTDIDriver.h
