build/objects/src/main/cpp/ACTServerApp/ACTServerMain.o: \
 src/main/cpp/ACTServerApp/ACTServerMain.cpp \
 src/main/include/ATL/ATLApplication.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ATL/ATLPlatform.h src/main/include/ATL/ATLError.h \
 src/main/include/ATL/ATLObject.h src/main/include/ARMCPP11/Atomic.h \
 src/main/include/ATL/ATLLogger.h src/main/include/ARMCPP11/Mutex.h \
 src/main/include/ATL/ATLTemplates.h src/main/include/ATL/ATLConfig.h \
 src/main/cpp/ACTServerApp/ACTServerApp.h
