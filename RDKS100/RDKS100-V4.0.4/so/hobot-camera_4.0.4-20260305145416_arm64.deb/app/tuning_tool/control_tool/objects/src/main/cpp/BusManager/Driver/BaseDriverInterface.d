build/objects/src/main/cpp/BusManager/Driver/BaseDriverInterface.o: \
 src/main/cpp/BusManager/Driver/BaseDriverInterface.cpp \
 src/main/include/BusManager/BaseDriverInterface.h \
 src/main/include/ATL/ATLTypes.h src/main/include/ATL/ATLPlatform.h \
 src/main/include/ATL/ATLObject.h src/main/include/ATL/ATLTypes.h \
 src/main/include/ARMCPP11/Atomic.h src/main/include/ATL/ATLTemplates.h \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLComponent.h \
 src/main/include/ATL/ATLObject.h src/main/include/ATL/ATLTemplates.h \
 src/main/include/ATL/ATLConfig.h \
 src/main/include/BusManager/TransferPacket.h \
 src/main/include/ATL/ATLError.h src/main/include/ATL/ATLLogger.h \
 src/main/include/ARMCPP11/Mutex.h
