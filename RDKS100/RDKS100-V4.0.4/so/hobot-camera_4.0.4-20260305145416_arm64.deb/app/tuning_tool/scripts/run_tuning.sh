#!/bin/bash

# j5 tuning menu script.
# -- by lmg 20210521

# menu file format:
# ITEM_<NAME>="[<SEL_DESC>:][SEL1][,SEL2][,...][;...]"
# <NAME>_<SEL1>()
# {
#	do something when select NAME/SEL1
# }

# bin.
exec_bin=/app/tuning_tool/bin/tuning_bin

# bin params evn:
# CPATH -- cam json path
# CJSON -- cam json
# CID   -- cam config index
# VPATH -- vpm json path
# VJSON -- vpm json
# VID   -- vpm pipeline id
# RTIME -- run timeout s
# WMODE -- work mode: feedback/sensor
# FFMT  -- fb raw format: raw8/raw12/raw16
# FLOOP -- fb loop count
# FPATH -- fb path
# AEINFO-- ae feedback
# CONTEXT  -- context feedback
# DUMP_CNT -- dump count before scanf
# HBPLAYER -- en hbplayer
# YNR      -- dump pic after YNR
# DUAL_SENSOR -- dual sensor
exec_params_default()
{
	# case desc.
	IDESC=

	# json path.
	VPATH=/app/tuning_tool/cfg/
	VJSON=
	VID=0
	CPATH=/app/tuning_tool/cfg/
	CJSON=hb_j6dev.json
	CID=0
	# run mode.
	WMODE=1
	RTIME=

	# isp fb config.
	FFMT=
	FLOOP=3000000
	FPATH=./
	SET_AEINFO=
	GET_AEINFO=
	SET_CONTEXT=
	GET_CONTEXT=

	# dump config.
	DUMP_CNT=
	HBPLAYER=1
	YNR=
	YNR_DEBUG=
	DUAL_SENSOR=
}

# bin params show.
exec_params_show()
{
	echo "~~ params:"
	for p in IDESC CPATH VPATH WMODE RTIME VJSON VID CJSON CID  FFMT FLOOP DUMP_CNT; do
		v=$(eval echo '$'${p})
		if [ ! -z "${v}" ]; then
			echo "${p}=${v}"
		fi
	done
}

# make sure json is rw.
# $1 - json file path.
p_mount_dir="/tmp/isp_json"
p_src_dir=
p_mount_flag=0
file_mount() {
	if [ -z "$1" ] || [ ! -e $1 ] || [ "${1:0:1}" != "/" ]; then
		echo File not exit!!!!!
		return 1
	fi

        if [ ${p_mount_flag} -eq 1 ]; then
                return 1
        fi

	dir=`dirname $1`
	#0 indicates has been mounted
	mountpoint -q ${dir}
	if [ $? -eq 0 ]; then
		umount ${dir}
	fi

	mountpoint -q ${dir}
	if [ $? -eq 0 ]; then
		echo $dir mountpoint check failed
		return 0
	fi

	mount_dir=${p_mount_dir}${dir}
	mkdir -p ${mount_dir}
	cp -f ${dir}/* ${mount_dir}
	busybox mount ${mount_dir} ${dir}
	p_mount_flag=1
	echo ==========mount $mount_dir to $dir
	p_src_dir=$1
	return 0
}

function file_umount() {
	if [ -z "$1" ] || [ ! -e $1 ] || [ "${1:0:1}" != "/" ]; then
		return 1
	fi
	dir=`dirname $1`
	umount $dir
	rm -rf $p_mount_dir
	p_mount_flag=0
	echo ==========umount $dir rm $p_mount_dir
	return 0
}

function cleanup {
	trap '' INT
	file_umount ${p_src_dir} &
	wait $!
	exit 0
}

trap cleanup INT
# replace json value.
# $1 - json file path.
# $2 - key name
# $3 - key value
# $4 - not g?
# $5 - location
# $6 - value is string?
json_setval()
{
	if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]; then
		echo "json_replace error: $1-$2-$3"
		exit 1
	fi
	if [ ! -f $1 ]; then
		echo "file $1 not exist"
		exit 1
	fi

	# eq=`cat $1 |grep "$2" |grep -w "$3"`
	# if [ ! -z "${eq}" ]; then
	# 	echo "-- $1: $2=$3"
	# 	return
	# fi
	echo "~~ $1: $2=$3"
	file_mount $1
	sed -i "s/\"$2\":\s*[0-9]*/\"$2\": $3/g" $1
	# if [ -z "$4" ]; then
	# 	if [ -z "$6" ]; then
	# 		sed -e "$5s#\"$2\"[ ]*:.*[^,]#\"$2\": $3#g" -i $1
	# 	else
	# 		sed -e "$5s#\"$2\"[ ]*:.*[^,]#\"$2\": \"$3\"#g" -i $1
	# 	fi
	# else
	# 	if [ -z "$6" ]; then
	# 		sed -e "$5s#\"$2\"[ ]*:.*[^,]#\"$2\": $3#" -i $1
	# 	else
	# 		sed -e "$5s#\"$2\"[ ]*:.*[^,]#\"$2\": \"$3\"#" -i $1
	# 	fi
	# fi
}

exec_params=
# bin params get.
# $? - saved to exec_params
exec_params_get()
{
	# params for vcs_test:
	# " -m       work mode:0 sensor, 1 feedback\n"
	# " -v       vpm_config path\n"
	# " -c       cam_config path\n"
	# " -p		 pipe_id\n"
	# " -i		 camera_index\n"
	# " -r       run time for isp tool (second)\n"
	# " -l       loop count for feedback mode\n"
	# " -E       enable hobotplayer\n"
	# " -b       enable get aeinfo\n"
	# " -B       enable set aeinfo\n"
	# " -z       enable get context\n"
	# " -Z       enable set context\n"
	# " -n       raw/context file path\n"
	# " -y       get yuv after ynr\n"
	# " -F       raw-format 1:raw8 2:raw12 3:raw16\n"
	# " -d       dump count brfore scanf\n"
	# check null.
	null_err=
	for p in WMODE VJSON CJSON; do
		v=$(eval echo '$'${p})
		if [ -z "${v}" ]; then
			null_err="${null_err} ${p}"
		fi
	done
	if [ ! -z "${null_err}" ]; then
		echo "** null config:${null_err}"
		exit 1
	fi

	exec_params="-m ${WMODE}"

	# get params.
	if [ ! -f ${VPATH}/${VJSON} ]; then
		echo "## VJSON not exist: ${VPATH}/${VJSON}"
	fi
	exec_params="${exec_params} -v ${VPATH}/${VJSON} -p ${VID}"
	if [ ! -f ${CPATH}/${CJSON} ]; then
		echo "## CJSON not exist: ${CPATH}/${CJSON}"
	fi
	exec_params="${exec_params} -c ${CPATH}/${CJSON} -i ${CID}"


	if [ ${WMODE} -eq 2 ]; then
		if [ -z "${FFMT}" ] || [ ${FFMT} -lt 1 ] || [ ${FFMT} -gt 4 ]; then
			echo "** FFMT not supported: ${FFMT}"
			exit 1
		fi
		exec_params="${exec_params} -F ${FFMT}"

		# Specify the dirpath for feedback	
		if [ -n "${FPATH}" ] && [ -d ${FPATH} ]; then
			exec_params="${exec_params} -D ${FPATH}"
		fi
		
		exec_params="${exec_params} -l ${FLOOP}"

		# modify isp output format
		if [ -n "${exec_fmt}" ]; then
			json_setval ${VPATH}/${VJSON} isp_dma_output_format ${exec_fmt}
		fi
	fi

	if [ ! -z "${DUMP_CNT}" ]; then
		exec_params="${exec_params} -d ${DUMP_CNT}"
	fi

	if [ ! -z "${GET_CONTEXT}" ]; then
		exec_params="${exec_params} -z 1"
	fi

	if [ ! -z "${SET_CONTEXT}" ]; then
		exec_params="${exec_params} -Z 1"
	fi

	if [ ! -z "${GET_AEINFO}" ]; then
		exec_params="${exec_params} -b 1"
	fi

	if [ ! -z "${SET_AEINFO}" ]; then
		exec_params="${exec_params} -B 1"
	fi

	if [ -z "${RTIME}" ]; then
		if [ ! -z "${runtime}" ]; then
			RTIME=${runtime}
		else
			RTIME=$((0x7FFFFFFF))
		fi
	fi
	exec_params="${exec_params} -r ${RTIME}"	
	if [ ! "0" -eq "${HBPLAYER}" ]; then
		exec_params="${exec_params} -E ${HBPLAYER}"
	fi

	if [ ! -z "${YNR}" ]; then
		exec_params="${exec_params} -y ${YNR}"
	fi

	if [ ! -z "${YNR_DEBUG}" ]; then
		exec_params="${exec_params} -Y ${YNR_DEBUG}"
	fi

	if [ ! -z "${DUAL_SENSOR}" ]; then
		exec_params="${exec_params} -M ${DUAL_SENSOR}"
	fi
}



ITEMS_EXEC=
ITEMS_CURRENT=
# set current item by name.
# $1 - item name.
# $? - from "ITEM_X=sel1:a,b;sel2:c,d", save to ITEMS_CURRENT
item_cur()
{
	ITEMS_CURRENT=$(eval echo '$'ITEM_$1)
}

# do select for one choice.
# $1 - select string list as "sel1:a,b"
# $2 - select by index
# $? - selected index(0-no select/255-back)
#      save to: SEL_IDX SEL_DESC SEL_KEY
item_select_one()
{
	#ssels=`echo $1 |awk -F ':' '{print $2}'`
	ssels=${1#*:}
	if [ -z "${ssels}" ]; then
		sdesc=
		ssels=$1
	else
		#sdesc=`echo $1 |awk -F ':' '{print $1}'`
		sdesc=${1%:*}
	fi
	#echo "one $1 + $2 --> sdesc=${sdesc} + ssels=${ssels}"

	slist=`echo ${ssels} |sed -e 's/,[,]*/,/g' -e 's/^,//' -e 's/,$//'`
	#slist=${ssels}
	# no select list.
	if [ -z "${slist}" ]; then
		SEL_IDX=0
		SEL_DESC=
		SEL_KEY=
		return ${SEL_IDX}
	fi
	# only one, not need select.
	sidx_max=${slist//[^,]/}
	sidx_max=$((${#sidx_max} + 1))
	if [ ${sidx_max} -eq 1 ]; then
		SEL_IDX=1
		SEL_DESC=${sdesc}
		SEL_KEY=${slist}
		return ${SEL_IDX}
	fi
	# some thing to select.
	sidx_def=
	if [ "${slist//,@/}" == "${slist}" ]; then
		# no @, default as 1.
		sidx_def=1
	fi
	# selected by $2?
	sidx_seled=
	if [ ! -z "$2" ]; then
		if [ $2 -ge 1 ] && [ $2 -le ${sidx_max} ]; then
			sidx_seled=$2
		else
			echo "## invalid selected index $2"
		fi
	fi
	# do select.
	sidx_ret=
	while [ -z "${sidx_ret}" ]; do
		if [ -z "${sidx_seled}" ]; then
			if [ ! -z "${sdesc}" ]; then
				echo ">> please select ${sdesc} by 1-${sidx_max}:"
			else
				echo ">> please select 1-${sidx_max}:"
			fi
		fi
		sidx=1
		for i in ${slist//,/ };do
			if [ "${i:0:1}" == "@" ]; then
				if [ -z "${sidx_def}" ]; then
					sidx_def=${sidx}
				fi
				sx=${i:1}
			else
				sx=$i
			fi
			if [ "${sx:0-1:1}" == "$" ]; then
				sxd=${sx::-1}
			else
				sxd=${sx}
			fi
			if [ -z "${sidx_seled}" ]; then
				# list the menu.
				if [ "${sidx_def}" == "${sidx}" ]; then
					echo " @ ${sidx} - ${sxd}"
				else
					echo "   ${sidx} - ${sxd}"
				fi
			else
				# select direct by $2.
				if [ ${sidx} -eq ${sidx_seled} ];then
					SEL_IDX=${sidx}
					SEL_DESC=${sdesc}
					SEL_KEY=${sx}
					return ${SEL_IDX}
				fi
			fi
			sidx=$((${sidx} + 1))
		done
		# input select index.
		echo -n "-> "
		read sidx_in
		if [ -z "${sidx_in}" ]; then
			# use default if ENTER.
			sidx_ret=${sidx_def}
		elif [ -z "${sidx_in//[0-9]*/}" ]; then
			# input 0-9 num.
			if [ ${sidx_in} -le 0 ] || [ ${sidx_in} -ge ${sidx} ]; then
				echo "## invalid index ${sidx_in}, shoule be 1-$((${sidx} - 1)):"
			else
				sidx_ret=${sidx_in}
			fi
		elif [ "${sidx_in:0:1}" = "b" ]; then
			# b for back.
			SEL_IDX=255
			SEL_DESC=${sdesc}
			SEL_KEY=
			return ${SEL_IDX}
		elif [ "${sidx_in:0:1}" = "q" ]; then
			# q for quit.
			exit 1
		else
			# other as invalid.
			echo "## invalid input ${sidx_in}, shoule be 1-$((${sidx} - 1)):"
		fi
	done
	# get selected string.
	sidx=1
	for i in ${slist//,/ };do
		if [ ${sidx_ret} -eq ${sidx} ]; then
			if [ "${i:0:1}" == "@" ]; then
				sstr="${i:1}"
			else
				sstr="${i}"
			fi
			break
		fi
		sidx=$((${sidx} + 1))
	done

	#echo "selected: ${sidx_ret} - ${sstr}"
	SEL_IDX=${sidx_ret}
	SEL_DESC=${sdesc}
	SEL_KEY=${sstr}
	return ${SEL_IDX}
}

ITEMS_IDX=
ITEMS_KEY=
# do select for one item.
# $1 - as "desp:a,b;..."
# $2 - as "1,2,3"
# $? - 255-back, >0-depth of select
item_select_do()
{
	#sdeps=`echo $1 |sed -e 's/;[;]*/;/g' -e 's/^;//' -e 's/;$//'`
	sdeps=$1
	dep_max=${sdeps//[^;]/}
	dep_max=$((${#dep_max} + 1))

	dep_idx=1
	idx_p=
	key_p=
	while [ ${dep_idx} -le ${dep_max} ]; do
		this_sel=`echo ${sdeps} |awk -F ';' '{print $i}' i=${dep_idx}`
		this_idx=`echo $2 |awk -F ',' '{print $i}' i=${dep_idx}`
		item_select_one "${this_sel}" "${this_idx}"
		ret=$?
		if [ $ret -eq 255 ]; then
			# back.
			idx_p=${idx_p%,*}
			key_p=${key_p%,*}
			dep_idx=$((${dep_idx} - 1))
			if [ ${dep_idx} -lt 1 ]; then
				return 255
			fi
			continue
		fi
		if [ "${SEL_KEY:0-1:1}" == "$" ]; then
			# xx$ as the last dep item.
			SEL_KEY=${SEL_KEY::-1}
			dep_max=${dep_idx}
		fi
		if [ ! -z "${SEL_DESC}" ]; then
			echo "<< ${SEL_DESC}: ${SEL_IDX} - ${SEL_KEY}"
		else
			echo "<< selected: ${SEL_IDX} - ${SEL_KEY}"
		fi
		idx_p="${idx_p},${SEL_IDX}"
		key_p="${key_p},${SEL_KEY}"
		dep_idx=$((${dep_idx} + 1))
	done
	ITEMS_IDX="${ITEMS_IDX}${idx_p}"
	ITEMS_KEY="${ITEMS_KEY}${key_p}"
	return ${dep_idx}
}

# do item select.
# $1 - item list as "A,B,C"
# $2 - item selected index as "1,2,3"
# $? - 255-back, 0-done, save to ITEMS_IDX ITEMS_KEY
item_select()
{
	ITEMS_IDX=
	ITEMS_KEY=

	sel_items="item:$1"
	#sel_name=`echo $2 |awk -F ',' '{print $1}'`
	sel_name=${2%%,*}
	if [ ! -z "${2//[^,]/}" ]; then
		sel_oth=${2#*,}
	else
		sel_oth=
	fi
	while [ -z "${ITEMS_KEY}" ]; do
		item_select_one "${sel_items}" "${sel_name}"
		ret=$?
		if [ ${ret} -eq 0 ] || [ ${ret} -eq 255 ]; then
			return ${ret}
		fi
		echo "<< ${SEL_DESC}: ${SEL_IDX} - ${SEL_KEY}"
		ITEMS_IDX=${SEL_IDX}
		ITEMS_KEY=${SEL_KEY}
		item_cur "${SEL_KEY}"
		item_select_do "${ITEMS_CURRENT}" "${sel_oth}"
		if [ $? -eq 255 ]; then
			ITEMS_IDX=
			ITEMS_KEY=
		fi
	done

	#echo "ITEMS_IDX=${ITEMS_IDX}"
	#echo "ITEMS_KEY=${ITEMS_KEY}"
	return 0
}

# item show one.
# $1 - item mode as "name:sel1,@sel2,..."
# $2 - selected?
# $3 - this_sel?
item_show_one()
{
	if [ -z "$1" ]; then
		return
	fi
	# item keys.
	ssels=`echo $1 |awk -F ':' '{print $2}'`
	if [ -z "${ssels}" ]; then
		ssels=$1
	else
		sdesc=`echo $1 |awk -F ':' '{print $1}'`
		# item key desc.
		echo "     + ${sdesc}"
	fi
	# item key selects.
	idy=1
	for y in ${ssels//,/ };do
		if [ ! -z "$2" ] && [ ! -z "$3" ] && [ "$3" == "${idy}" ]; then
			spre1="----->"
		else
			spre1="      "
		fi
		if [ "${y:0:1}" == "@" ]; then
			spre2="@"
			sy=${y:1}
		else
			spre2=" "
			sy=${y}
		fi
		if [ "${sy:0-1:1}" == "$" ]; then
			sy=${sy::-1}
		fi
		echo "${spre1}${spre2} ${idy} - ${sy}"
		idy=$((${idy} + 1))
	done

}

# item show.
# $1 - item list as "A,B,C"
# $2 - item selected index as "1,2,3"
# $3 - show depth max
# $? - 255-back, 0-done, save to ITEMS_IDX ITEMS_KEY
item_show()
{
	idx=1
	selected=
	echo "ITEMS:"
	for i in ${1//,/ };do
		dep_idx=1
		# item name.
		this_sel=`echo $2 |awk -F ',' '{print $i}' i=${dep_idx}`
		if [ ! -z "${this_sel}" ] && [ "${this_sel}" == "${idx}" ]; then
			spre1=">"
			selected=y
		else
			spre1=" "
			selected=
		fi
		echo "${spre1}  ${idx} - ${i}"
		idx=$((${idx} + 1))
		if [ ! -z "$3" ] && [ ${dep_idx} -ge $3 ]; then
			continue
		fi
		dep_idx=$((${dep_idx} + 1))
		item_cur "${i}"
		for x in ${ITEMS_CURRENT//;/ };do
			this_sel=`echo $2 |awk -F ',' '{print $i}' i=${dep_idx}`
			item_show_one "$x" "${selected}" "${this_sel}"
			# return for depth.
			if [ ! -z "$3" ] && [ ${dep_idx} -ge $3 ]; then
				break
			fi
			dep_idx=$((${dep_idx} + 1))
		done
	done
}

# item run.
# $1 - item keys from ITEMS_KEY
# $? - 255-exit, 0-done
item_run()
{
	kfun=
	kcnt=0
	knext=1
	for k in ${1//,/ };do
		if [ -z "${kfun}" ]; then
			kfun="${k}"
		else
			kfun="${kfun}_${k}"
		fi
		kis=$(type ${kfun} 2>/dev/null |grep "function")
		knext=$((${knext} + 1))
		if [ ! -z "${kis}" ]; then
			echo " + ${kfun}()"
			# $@ - current and followed items.
			f=`echo $1 |awk -v n=${knext} -F ',' '{for (i=n;i<=NF;i++) print $i}'`
			#echo ${kfun} ${k} ${f}
			${kfun} ${k} ${f}
			kcnt=$((${kcnt} + 1))
		else
			echo " - ${kfun}()"
		fi
	done
	if [ ${kcnt} -eq 0 ]; then
		echo "** no valid config func"
		return 255
	fi
}

# params default.
exec_params_default
# script params.
menu_file=./tuning_menu.sh
if [ ! -e ${menu_file} ]; then
	menu_file=/app/tuning_tool/scripts/tuning_menu.sh
fi
run_sel=
run_items=
loglevel=
printk=
show_it=
runtime=
notrun=
exec_fmt=

# args.
for arg in "$@"; do
	if [ "${arg}" == "-h" ]; then
cat <<EOF
`basename $0` [.sh] [#] [r#] [g#] [G#] [D#] [E] [a] [x#] [n] [-h]
  .sh      -- case menu files, default as ${menu_file}
  #        -- menu select index list
  r#       -- runtime seconds
  g#       -- userspace loglevel
  G#       -- kernel loglevel
  D#       -- isp dump(-M 8 -D 1): cnt default ${dump_cnt}
  a        -- run with yuv+raw16(A for yuv+raw12, a# for oth fmt) for hbplayer
  E        -- enable ae_info for isp feedback
  x#       -- show all support items as depth
  n        -- not run, only show info
  -h       -- show this help tips
EOF
		exit 0
	elif [ "${arg:0-3}" == ".sh" ]; then
		menu_file="${menu_file} ${arg}"
	elif [ "${arg/[0-9]*/}" == "" ]; then
		if [ -z "${run_sel}" ]; then
			run_sel="${arg}"
		else
			run_sel="${run_sel},${arg}"
		fi
	elif [ "${arg/r[0-9]*/}" == "" ]; then
		runtime="${arg/r/}"
	elif [ "${arg/g[0-9]*/}" == "" ]; then
		loglevel="${arg/g/}"
	elif [ "${arg/G[0-9]*/}" == "" ]; then
		printk="${arg/G/}"
	elif [ "${arg/d[0-9]*/}" == "" ]; then
		DUMP_CNT="${arg/d/}"
		echo $DUMP_CNT
	elif [ "${arg/x[0-9]*/}" == "" ]; then
		show_it="${arg/x/}"
	elif [ "${arg}" == "x" ]; then
		show_it=255
	elif [ "${arg/a[0-9]*/}" == "" ]; then
		exec_fmt="${arg/a/}"
	elif [ "${arg/z[0-9]*/}" == "" ]; then
		GET_CONTEXT="${arg/z/}"
	elif [ "${arg/Z[0-9]*/}" == "" ]; then
		SET_CONTEXT="${arg/Z/}"
	elif [ "${arg/b[0-9]*/}" == "" ]; then
		GET_AEINFO="${arg/b/}"
	elif [ "${arg/B[0-9]*/}" == "" ]; then
		SET_AEINFO="${arg/B/}"
	elif [ "${arg/l[0-9]*/}" == "" ]; then
		FLOOP="${arg/l/}"
	elif [ "${arg/E[0-9]*/}" == "" ]; then
		HBPLAYER="${arg/E/}"
	elif [ "${arg/y[0-9]*/}" == "" ]; then
		YNR="${arg/y/}"
	elif [ "${arg/Y[0-9]*/}" == "" ]; then
		YNR_DEBUG="${arg/Y/}"
	elif [ "${arg}" == "n" ]; then
		notrun=y
	else
		echo "${arg} not support"
		exit 1
	fi
done
# source menu files.
for f in ${menu_file}; do
	if [ -e ${f} ]; then
		source ${f}
	else
		echo "** ${f} not exist and ignore"
	fi
done
run_items=`set |grep "^ITEM_.*=" |awk -F '=' '{print $1}' |sed -e 's/^ITEM_//' |tr '\n' ','`
# items valid?
if [ -z "${run_items}" ]; then
	echo "** no valid item case"
	exit 1
fi

# x/X for show.
if [ ! -z "${show_it}" ]; then
	item_show "${run_items}" "${run_sel}" "${show_it}"
	exit 0
fi

# item select do.
item_select "${run_items}" "${run_sel}"
ret=$?
if [ ${ret} -eq 255 ]; then
	exit ${ret}
fi


# item run.
echo "== `echo ${ITEMS_IDX} |sed 's/,/ /g'`: `echo ${ITEMS_KEY}|sed 's/,/_/g'`"
item_run "${ITEMS_KEY}"
ret=$?
if [ ${ret} -eq 255 ]; then
	exit ${ret}
fi

# item desc.
if [ -z "${IDESC}" ]; then
	IDESC="`echo ${ITEMS_KEY}|sed 's/,/_/g'`"
fi

# exec bin check.
if [ -z "${ITEMS_EXEC}" ]; then
	if [ ! -f ${exec_bin} ]; then
		if [ ! -z "${notrun}" ]; then
			exec_params_show
		else
			echo "** ${exec_bin} not exist"
			exit 1
		fi
	else
		exec_params=
	fi
fi

# show without run.
if [ ! -z "${notrun}" ]; then
	echo "[[ ${IDESC} ]]"
	if [ -z "${ITEMS_EXEC}" ]; then
		exec_params_get
		echo "${exec_bin} ${exec_params}"
	else
		echo "${ITEMS_EXEC}"
	fi
	if [ ! -z "${loglevel}" ]; then
		echo ">> LOGLEVEL=${loglevel}"
	elif [ ! -z "${LOGLEVEL}" ]; then
		echo ">> LOGLEVEL=${LOGLEVEL}"
	fi
	if [ ! -z "${printk}" ]; then
		echo ">> printk=${printk}"
	fi
	exit 0
fi

# loglevel.
#export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:`pwd`"
if [ ! -z "${loglevel}" ]; then
	export LOGLEVEL=${loglevel}
fi
if [ ! -z "${printk}" ]; then
	echo ${printk} >/proc/sys/kernel/printk
fi

# tunning run.
echo "[[ ${IDESC} ]]"
if [ -z "${ITEMS_EXEC}" ]; then
	if [ ! -x ${exec_bin} ]; then
		chmod +x ${exec_bin}
	fi
	exec_params_get
	echo "${exec_bin} ${exec_params}"
	${exec_bin} ${exec_params}
	ret=$?
else
	echo "${ITEMS_EXEC}"
	${ITEMS_EXEC}
	ret=$?
fi
file_umount ${p_src_dir}
exit ${ret}

