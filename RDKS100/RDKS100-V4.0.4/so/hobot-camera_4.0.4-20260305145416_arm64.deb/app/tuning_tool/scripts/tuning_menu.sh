#!/bin/sh

# menu for j5 tuning.
# sourced by run_tuning.sh.
# -- by lmg 20210521.

# common func.
# $1 - subdir of case, empty as drop
# $2 - camera index, empty as 0
host=`hostname`
boardid=`hrut_boardid`
folder=''
if [ -z $host ]; then
	echo "Hostname null"
	exit 1
else
	echo "Hostname: $host"
fi

if [ $host == "j5dvb" ]; then
	folder='bugfix'
elif [ $boardid == "0xE8" ]; then
	folder='starfish'
else
	folder='matrix'
fi
if [ ! -z "$TUNING_BOARD" ]; then
	folder="$TUNING_BOARD"
fi
echo "Folder: $folder"
setup_case()
{
	if [ -z "$1" ]; then
		return
	fi
	if [ ! -d ${VPATH}/$1 ]; then
		echo "** ${VPATH} no case sub: $1"
		if [ -z "${notrun}" ]; then
			exit 1
		fi
	fi
	if [ ! -z "${exec_bysh}" ]; then
		ITEMS_EXEC="${exec_bysh} $1"
	else
		if [ -z "$2" ]; then
			# use cam json of subdir with config_0.
			CID=0
		else
			# use cjson of cam/cfg.
			CID=$2
		fi
		# use cam&vpm json of subdir.
		CJSON=$1/${CJSON}
		VJSON=$1/vpm_config.json
	fi
}

# $1 - width
# $2 - height
# $3 - format: data_width: 8,10,12,16,... (0 as 12)
# $4 - format: bayer_start: 0-R,1-GR,2-GB,3-B,4-IR,5-C,6-CY
# $5 - format: bayer_pattern: 0-RGGB,1-RCCB,2-RIRGB,3-RGIRB,4-RCCB,5-RYYCY
# $6 - format: max_bit_width: 12,16,20,24 (0 as 24)
# $7 - ynr: enable/disable
setup_feedback()
{
	if [ "$7" == "disable" ]; then
		setup_case ${folder}/tuning_feedback_ddr_isp_common
	elif [ "$7" == "enable" ]; then
		setup_case ${folder}/tuning_feedback_ddr_isp_ynr_common
		YNR=1
	else
		echo "ynr setup error"
	fi

	if [ -f ${VPATH}/${VJSON} ]; then
		if [ ! -z "$1" ]; then
			json_setval ${VPATH}/${VJSON} width $1
			if [ "$7" == "enable" ]; then
				json_setval ${VPATH}/${VJSON} src_in_width $1
				json_setval ${VPATH}/${VJSON} src_in_stride_y $1
				json_setval ${VPATH}/${VJSON} src_in_stride_uv $1
				json_setval ${VPATH}/${VJSON} ds_roi_region_width $1
				json_setval ${VPATH}/${VJSON} ds_roi_wstride_y $1
				json_setval ${VPATH}/${VJSON} ds_roi_wstride_uv $1
				json_setval ${VPATH}/${VJSON} ds_roi_out_width $1
			fi
		fi
		if [ ! -z "$2" ]; then
			json_setval ${VPATH}/${VJSON} height $2
			if [ "$7" == "enable" ]; then
				json_setval ${VPATH}/${VJSON} src_in_height $2
				json_setval ${VPATH}/${VJSON} ds_roi_region_height $2
				json_setval ${VPATH}/${VJSON} ds_roi_out_height $2
			fi
		fi
	fi
	if [ -f ${CPATH}/${CJSON} ]; then
		fmt_do=
		fmt=0
		if [ ! -z "$3" ]; then
			fmt=$(($3))
			fmt_do=y
		fi
		if [ ! -z "$4" ]; then
			fmt=$((${fmt} + ($4 << 8)))
			fmt_do=y
		fi
		if [ ! -z "$5" ]; then
			fmt=$((${fmt} + ($5 << 12)))
			fmt_do=y
		fi
		if [ ! -z "$6" ]; then
			fmt=$((${fmt} + ($6 << 24)))
			fmt_do=y
		fi
		if [ ! -z "${fmt_do}" ]; then
			json_setval ${CPATH}/${CJSON} format ${fmt}
		fi
	fi
}

# Feedback.
ITEM_Feedback="format:3840x2160_12bit_msb,3840x2160_16bit_msb,1920x1080_12bit_msb,1920x1080_16bit_msb,2048x1280_16bit_msb,1920x1280_16bit_msb;bayer:RGGB,GRBG,RBRG,BGGR;bits:12,16,20,@24;ynr:disable,enable"
Feedback()
{
	WMODE=2
}
feedback_12bit_rggb_common()
{
	IDESC="feedback 12bit/${5} ${2}x${3} $1 raw from ${FPATH}"
	FFMT=2
	setup_feedback "$2" "$3" 12 "$4" 0 "$5" "$6"
}
feedback_16bit_rggb_common()
{
	IDESC="feedback 16bit/${5} ${2}x${3} $1 raw from ${FPATH}"
	FFMT=3
	setup_feedback "$2" "$3" 16 "$4" 0 "$5" "$6"
}
Feedback_3840x2160_12bit_msb_RGGB()
{
	feedback_12bit_rggb_common "$1" 3840 2160 0 "$2" "$3"
}
Feedback_3840x2160_12bit_msb_GRBG()
{
	feedback_12bit_rggb_common "$1" 3840 2160 1 "$2" "$3"
}
Feedback_3840x2160_12bit_msb_RBRG()
{
	feedback_12bit_rggb_common "$1" 3840 2160 2 "$2" "$3"
}
Feedback_3840x2160_12bit_msb_BGGR()
{
	feedback_12bit_rggb_common "$1" 3840 2160 3 "$2" "$3"
}
Feedback_3840x2160_16bit_msb_RGGB()
{
	feedback_16bit_rggb_common "$1" 3840 2160 0 "$2" "$3"
}
Feedback_3840x2160_16bit_msb_GRBG()
{
	feedback_16bit_rggb_common "$1" 3840 2160 1 "$2" "$3"
}
Feedback_3840x2160_16bit_msb_RBRG()
{
	feedback_16bit_rggb_common "$1" 3840 2160 2 "$2" "$3"
}
Feedback_3840x2160_16bit_msb_BGGR()
{
	feedback_16bit_rggb_common "$1" 3840 2160 3 "$2" "$3"
}
Feedback_1920x1080_12bit_msb_RGGB()
{
	feedback_12bit_rggb_common "$1" 1920 1080 0 "$2" "$3"
}
Feedback_1920x1080_12bit_msb_GRBG()
{
	feedback_12bit_rggb_common "$1" 1920 1080 1 "$2" "$3"
}
Feedback_1920x1080_12bit_msb_RBRG()
{
	feedback_12bit_rggb_common "$1" 1920 1080 2 "$2" "$3"
}
Feedback_1920x1080_12bit_msb_BGGR()
{
	feedback_12bit_rggb_common "$1" 1920 1080 3 "$2" "$3"
}
Feedback_1920x1080_16bit_msb_RGGB()
{
	feedback_16bit_rggb_common "$1" 1920 1080 0 "$2" "$3"
}
Feedback_1920x1080_16bit_msb_GRBG()
{
	feedback_16bit_rggb_common "$1" 1920 1080 1 "$2" "$3"
}
Feedback_1920x1080_16bit_msb_RBRG()
{
	feedback_16bit_rggb_common "$1" 1920 1080 2 "$2" "$3"
}
Feedback_1920x1080_16bit_msb_BGGR()
{
	feedback_16bit_rggb_common "$1" 1920 1080 3 "$2" "$3"
}
Feedback_2048x1280_16bit_msb_RGGB()
{
	feedback_16bit_rggb_common "$1" 2048 1280 0 "$2" "$3"
}
Feedback_2048x1280_16bit_msb_GRBG()
{
	feedback_16bit_rggb_common "$1" 2048 1280 1 "$2" "$3"
}
Feedback_2048x1280_16bit_msb_RBRG()
{
	feedback_16bit_rggb_common "$1" 2048 1280 2 "$2" "$3"
}
Feedback_2048x1280_16bit_msb_BGGR()
{
	feedback_16bit_rggb_common "$1" 2048 1280 3 "$2" "$3"
}

Feedback_1920x1280_16bit_msb_RGGB()
{
	feedback_16bit_rggb_common "$1" 1920 1280 0 "$2" "$3"
}
Feedback_1920x1280_16bit_msb_GRBG()
{
	feedback_16bit_rggb_common "$1" 1920 1280 1 "$2" "$3"
}
Feedback_1920x1280_16bit_msb_RBRG()
{
	feedback_16bit_rggb_common "$1" 1920 1280 2 "$2" "$3"
}
Feedback_1920x1280_16bit_msb_BGGR()
{
	feedback_16bit_rggb_common "$1" 1920 1280 3 "$2" "$3"
}
# OVX3C.
ITEM_OVX3C_RGGB="module:Pwl12_LCE_Fov60,Pwl12_LCE_Fov60_YNR,Pwl12_LCE_Fov100,Pwl12_LCE_Fov100_YNR,Pwl12_GA_Fov100,Pwl12_SN_Fov100"
OVX3C_RGGB_Pwl12_LCE_Fov100()
{
	IDESC="ovx3c rggb lce 1920x1280 pwl raw12 Fov100"
	setup_case ${folder}/tuning_ovx3clceFov100_cim_isp_1280p
}

OVX3C_RGGB_Pwl12_LCE_Fov60()
{
	IDESC="ovx3c rggb lce 1920x1280 pwl raw12 Fov60"
	setup_case ${folder}/tuning_ovx3clceFov60_cim_isp_1280p
}
OVX3C_RGGB_Pwl12_LCE_Fov100_YNR()
{
	IDESC="ovx3c rggb lce 1920x1280 pwl raw12 Fov100 YNR"
	YNR=1
	setup_case ${folder}/tuning_ovx3clceFov100_cim_isp_ynr_1280p
}
OVX3C_RGGB_Pwl12_LCE_Fov60_YNR()
{
	IDESC="ovx3c rggb lce 1920x1280 pwl raw12 Fov60 YNR"
	YNR=1
	setup_case ${folder}/tuning_ovx3clceFov60_cim_isp_ynr_1280p
}
OVX3C_RGGB_Pwl12_GA_Fov100()
{
	IDESC="ovx3c rggb GA(GALAXY) 1920x1280 pwl raw12 Fov100"
	setup_case ${folder}/tuning_ovx3cgaFov100_cim_isp_1280p
}
OVX3C_RGGB_Pwl12_SN_Fov100()
{
	IDESC="ovx3c rggb SN(SUNNY) 1920x1280 pwl raw12 Fov100"
	setup_case ${folder}/tuning_ovx3csnFov100_cim_isp_1280p
}
# OVX8B.
ITEM_OVX8B_RGGB="module:Pwl12_PH_Fov120,Pwl12_SN_Fov120,Pwl12_SN_Fov30,Pwl12_LCE_Fov30,Pwl12_LCE_Fov120,Pwl12_HK_Fov120,Pwl12_HK_Fov30"
OVX8B_RGGB_Pwl12_PH_Fov120()
{
	IDESC="ovx8b rggb PH 3840x2160 pwl raw12 Fov120"
	setup_case ${folder}/tuning_ovx8bphFov120_cim_isp_4k
}
OVX8B_RGGB_Pwl12_SN_Fov120()
{
	IDESC="ovx8b rggb SN 3840x2160 pwl raw12 Fov120"
	setup_case ${folder}/tuning_ovx8bsnFov120_cim_isp_4k
}
OVX8B_RGGB_Pwl12_SN_Fov30()
{
	IDESC="ovx8b rggb SN 3840x2160 pwl raw12 Fov30"
	setup_case ${folder}/tuning_ovx8bsnFov30_cim_isp_4k
}
OVX8B_RGGB_Pwl12_LCE_Fov30()
{
        IDESC="ovx8b rggb lce 3840x2160 pwl raw12 Fov30"
        setup_case ${folder}/tuning_ovx8blceFov30_cim_isp_4k
}
OVX8B_RGGB_Pwl12_LCE_Fov120()
{
        IDESC="ovx8b rggb lce 3840x2160 pwl raw12 Fov120"
        setup_case ${folder}/tuning_ovx8blceFov120_cim_isp_4k
}
OVX8B_RGGB_Pwl12_HK_Fov120()
{
	IDESC="ovx8b rggb HK 3840x2160 pwl raw12 Fov120"
	setup_case ${folder}/tuning_ovx8bhkFov120_cim_isp_4k
}
OVX8B_RGGB_Pwl12_HK_Fov30()
{
	IDESC="ovx8b rggb HK 3840x2160 pwl raw12 Fov30"
	setup_case ${folder}/tuning_ovx8bhkFov30_cim_isp_4k
}
# AR0820.
ITEM_AR0820_RGGB="module:Pwl12_WS_Fov120,Pwl12_SY_Fov30,Pwl12_GA_Fov120,Pwl12_GA_Fov30;res:4K,1080P_BINNING_DIG,1080P_BINNING_ANA,1080P_SCALING"
AR0820_RGGB_Pwl12_WS_Fov120_4K()
{
	IDESC="ar0820 rggb WS(SUNNY) 4k pwl raw12 Fov120"
	setup_case ${folder}/tuning_ar0820snFov120_cim_isp_4k
}
AR0820_RGGB_Pwl12_WS_Fov120_1080P_BINNING_DIG()
{
	IDESC="ar0820 rggb WS(SUNNY) 1080p(binning_dig) pwl raw12 Fov120"
	setup_case ${folder}/tuning_ar0820snFov120_cim_isp_1080p_binning_dig
}
AR0820_RGGB_Pwl12_WS_Fov120_1080P_BINNING_ANA()
{
	IDESC="ar0820 rggb WS(SUNNY) 1080p(binning_ana) pwl raw12 Fov120"
	setup_case ${folder}/tuning_ar0820snFov120_cim_isp_1080p_binning_ana
}
AR0820_RGGB_Pwl12_WS_Fov120_1080P_SCALING()
{
	IDESC="ar0820 rggb WS(SUNNY) 1080p(scaling) pwl raw12 Fov120"
	setup_case ${folder}/tuning_ar0820snFov120_cim_isp_1080p_scaling
}
AR0820_RGGB_Pwl12_SY_Fov30_4K()
{
	IDESC="ar0820 rggb SY 4k pwl raw12 Fov30"
	setup_case ${folder}/tuning_ar0820syFov30_cim_isp_4k
}
AR0820_RGGB_Pwl12_SY_Fov30_1080P_BINNING_DIG()
{
	IDESC="ar0820 rggb SY 1080p(binning_dig) pwl raw12 Fov30"
	setup_case ${folder}/tuning_ar0820syFov30_cim_isp_1080p_binning_dig
}
AR0820_RGGB_Pwl12_SY_Fov30_1080P_BINNING_ANA()
{
	IDESC="ar0820 rggb SY 1080p(binning_ana) pwl raw12 Fov30"
	setup_case ${folder}/tuning_ar0820syFov30_cim_isp_1080p_binning_ana
}
AR0820_RGGB_Pwl12_SY_Fov30_1080P_SCALING()
{
	IDESC="ar0820 rggb SY 1080p(scaling) pwl raw12 Fov30"
	setup_case ${folder}/tuning_ar0820syFov30_cim_isp_1080p_scaling
}
AR0820_RGGB_Pwl12_GA_Fov120_4K()
{
	IDESC="ar0820 rggb GA(GALAXY) 4k pwl raw12 Fov120"
	setup_case ${folder}/tuning_ar0820gaFov120_cim_isp_4k
}
AR0820_RGGB_Pwl12_GA_Fov120_1080P_BINNING_DIG()
{
	IDESC="ar0820 rggb GA(GALAXY) 1080p(binning_dig) pwl raw12 Fov120"
	setup_case ${folder}/tuning_ar0820gaFov120_cim_isp_1080p_binning_dig
}
AR0820_RGGB_Pwl12_GA_Fov120_1080P_BINNING_ANA()
{
	IDESC="ar0820 rggb GA(GALAXY) 1080p(binning_ana) pwl raw12 Fov120"
	setup_case ${folder}/tuning_ar0820gaFov120_cim_isp_1080p_binning_ana
}
AR0820_RGGB_Pwl12_GA_Fov120_1080P_SCALING()
{
	IDESC="ar0820 rggb GA(GALAXY) 1080p(scaling) pwl raw12 Fov120"
	setup_case ${folder}/tuning_ar0820gaFov120_cim_isp_1080p_scaling
}
AR0820_RGGB_Pwl12_GA_Fov30_4K()
{
	IDESC="ar0820 rggb GA(GALAXY) 4k hdr4 24bit pwl raw12 Fov30"
	setup_case ${folder}/tuning_ar0820gaFov30_cim_isp_4k
}
ITEM_AR0233_RGGB="module:Pwl12_GA_Fov123"
AR0233_RGGB_Pwl12_GA_Fov123()
{
	IDESC="ar0820 rggb GA(GALAXY) 1280p pwl raw12 Fov30"
	setup_case ${folder}/tuning_ar0233gaFov123_cim_isp_1280p
}
ITEM_OV2311_RGGB="module:Linear10_ZH_Fov54,Linear10_ZH_Fov54_YNR"
OV2311_RGGB_Linear10_ZH_Fov54()
{
	IDESC="ov2311 rggb LH linear raw10 Fov54"
	setup_case ${folder}/tuning_ov2311lhFov54
}
OV2311_RGGB_Linear10_ZH_Fov54_YNR()
{
	IDESC="ov2311 rggb LH linear raw10 Fov54 ynr"
	YNR=1
	setup_case ${folder}/tuning_ov2311lhFov54_ynr
}
ITEM_OVX8D_RGGB="module:Pwl12_SY_Fov121, Pwl12_SY_Fov121_DUAL"
OVX8D_RGGB_Pwl12_SY_Fov121()
{
	IDESC="ovx8d rggb SY pwl raw12 Fov121"
	setup_case ${folder}/tuning_ovx8dsyFov121_cim_isp_4k
}
OVX8D_RGGB_Pwl12_SY_Fov121_DUAL()
{
	IDESC="ovx8d rggb SY pwl raw12 Fov121 dual"
	DUAL_SENSOR=1
	setup_case ${folder}/tuning_ovx8dsyFov121_cim_isp_4k_dual
}
ITEM_IMX728_RCCG="module:Pwl12_SY_Fov120,Pwl12_LCE_Fov120"
IMX728_RCCG_Pwl12_SY_Fov120()
{
	IDESC="imx728 rccg SY pwl raw12 Fov120"
	setup_case ${folder}/tuning_imx728syFov120_cim_isp_4k
}
IMX728_RCCG_Pwl12_LCE_Fov120()
{
        IDESC="imx728 rccg LCE pwl raw12 Fov120"
        setup_case ${folder}/tuning_imx728lceFov120_cim_isp_4k
}
ITEM_IMX728_RGGB="module:Pwl12_SF_Fov121"
IMX728_RGGB_Pwl12_SF_Fov121()
{
        IDESC="imx728 rggb Starfish pwl raw12 Fov121"
        setup_case ${folder}/tuning_imx728sfFov121_cim_isp_4k
}
ITEM_IMX219_RGGB="module:Raw10_IMX219_RDK-S100"
IMX219_RGGB_Raw10_IMX219_RDK-S100()
{
	IDESC="imx219 rggb raw10 RDK-S100"
	YNR=1
	setup_case ${folder}/tuning_imx219_cim_isp_1080p
}
ITEM_OV9782_RGGB="module:1280X720_120FPS,1280X720_30FPS,640X360_200FPS, 1280X720_120FPS_DUAL, 640X360_200FPS_DUAL"
OV9782_RGGB_1280X720_120FPS()
{
	IDESC="ov9782 rggb raw10 1280x720@120fps RDK-S100"
	YNR=1
	setup_case ${folder}/tuning_ov9782_cim_isp_720p_120fps
}
OV9782_RGGB_1280X720_30FPS()
{
	IDESC="ov9782 rggb raw10 1280x720@30fps RDK-S100"
	YNR=1
	setup_case ${folder}/tuning_ov9782_cim_isp_720p_30fps
}
OV9782_RGGB_640X360_200FPS()
{
	IDESC="ov9782 rggb raw10 640X360@200fps RDK-S100"
	YNR=1
	setup_case ${folder}/tuning_ov9782_cim_isp_360p_200fps
}
OV9782_RGGB_1280X720_120FPS_DUAL()
{
	IDESC="ov9782 dual rggb raw10 1280x720@120fps RDK-S100"
	YNR=1
	DUAL_SENSOR=1
	setup_case ${folder}/tuning_ov9782_cim_isp_720p_120fps_dual
}
OV9782_RGGB_640X360_200FPS_DUAL()
{
	IDESC="ov9782 dual rggb raw10 640X360@200fps RDK-S100"
	YNR=1
	DUAL_SENSOR=1
	setup_case ${folder}/tuning_ov9782_cim_isp_360p_200fps_dual
}
ITEM_SC1336_BGGR="module:Raw10_SC1336_RDK-S100"
SC1336_BGGR_Raw10_SC1336_RDK-S100()
{
	IDESC="sc1336 bggr raw10 RDK-S100"
	YNR=1
	setup_case ${folder}/tuning_sc1336_cim_isp_720p
}
ITEM_SC132GS_BGGR="module:Raw10_SC132GS_RDK-S100, Raw10_SC132GS_DUAL_RDK-S100"
SC132GS_BGGR_Raw10_SC132GS_RDK-S100()
{
	IDESC="sc132gs bggr raw10 RDK-S100"
	YNR=1
	setup_case ${folder}/tuning_sc132gs_cim_isp_1088_1280
}
SC132GS_BGGR_Raw10_SC132GS_DUAL_RDK-S100()
{
	IDESC="sc132gs dual bggr raw10 RDK-S100"
	YNR=1
	DUAL_SENSOR=1
	setup_case ${folder}/tuning_sc132gs_dual_cim_isp_1088_1280
}
ITEM_SC230AI_BGGR="module:Raw10_SC230AI_RDK-S100, Raw10_SC230AI_DUAL_RDK-S100"
SC230AI_BGGR_Raw10_SC230AI_RDK-S100()
{
	IDESC="sc230ai bggr raw10 RDK-S100"
	YNR=1
	setup_case ${folder}/tuning_sc230ai_cim_isp_1080p
}
SC230AI_BGGR_Raw10_SC230AI_DUAL_RDK-S100()
{
	IDESC="sc230ai dual bggr raw10 RDK-S100"
	YNR=1
	DUAL_SENSOR=1
	setup_case ${folder}/tuning_sc230ai_dual_cim_isp_1080p
}
